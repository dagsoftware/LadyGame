<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs_CZ">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>About</name>
    <message>
        <location filename="about.ui" line="14"/>
        <source>About game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about.ui" line="76"/>
        <source>The Draughts game - version 1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about.ui" line="96"/>
        <source>Developers:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dama</name>
    <message>
        <location filename="dama.ui" line="14"/>
        <source>Dama2013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="41"/>
        <source>Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="55"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="61"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="72"/>
        <source>Main toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="88"/>
        <source>Replay toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="108"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="117"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="126"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="135"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="144"/>
        <source>About game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="153"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="162"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="171"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="180"/>
        <source>Play auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="183"/>
        <source>Play automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="192"/>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="195"/>
        <source>Pause replay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="204"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="207"/>
        <source>Back last draught</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="216"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="219"/>
        <source>Next draught</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="228"/>
        <location filename="dama.ui" line="231"/>
        <source>Load replay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.ui" line="240"/>
        <location filename="dama.ui" line="243"/>
        <source>Back to origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="36"/>
        <source>Step time (sec.ms)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="39"/>
        <source>Up to draught no. (0 = all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="41"/>
        <source>Current/End draught no.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="75"/>
        <location filename="dama.cpp" line="98"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="75"/>
        <location filename="dama.cpp" line="98"/>
        <source>Dama2013 (*.txt *.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="91"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="92"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="114"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dama.cpp" line="115"/>
        <source>Dama2013-TXT (*.txt);;Dama2013-XML (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Game</name>
    <message>
        <location filename="game.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="game.cpp" line="162"/>
        <location filename="game.cpp" line="249"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="game.cpp" line="163"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="game.cpp" line="206"/>
        <location filename="game.cpp" line="209"/>
        <source>Congratulations!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="game.cpp" line="206"/>
        <source>White player won!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="game.cpp" line="209"/>
        <source>Black player won!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="game.cpp" line="249"/>
        <source>Unknown file type.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InsertGameCode</name>
    <message>
        <location filename="insert_gamecode.ui" line="14"/>
        <source>Insert game code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="insert_gamecode.ui" line="20"/>
        <source>Please insert game code to replay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetGameDemand</name>
    <message>
        <location filename="ngame_demand.ui" line="14"/>
        <source>Network game demand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ngame_demand.ui" line="45"/>
        <source>Player with ip XXXX wants play game with you.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ngame_demand.ui" line="58"/>
        <source>Allow?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewGame</name>
    <message>
        <location filename="new_game.ui" line="14"/>
        <source>New game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="27"/>
        <source>Local game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="45"/>
        <source>1 player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="64"/>
        <source>2 players</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="77"/>
        <source>You vs. computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="90"/>
        <source>You vs. friend on same computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="104"/>
        <source>white</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="109"/>
        <source>black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="123"/>
        <source>Your color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="129"/>
        <source>Network game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="150"/>
        <source>Host Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="163"/>
        <source>Join Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="208"/>
        <source>Host Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_game.ui" line="215"/>
        <source>Host IP:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="settings.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="56"/>
        <source>Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="71"/>
        <source>Default color of draughtsmen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="78"/>
        <source>Default delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="89"/>
        <source>white</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="94"/>
        <source>black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="108"/>
        <location filename="settings.ui" line="145"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="121"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="126"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="131"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SureAbout</name>
    <message>
        <location filename="sure_about.ui" line="14"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sure_about.ui" line="31"/>
        <source>Are you sure you want abort this game?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WhetherReplay</name>
    <message>
        <location filename="whether_replay.ui" line="14"/>
        <source>This game is finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="whether_replay.ui" line="45"/>
        <source>This game is already finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="whether_replay.ui" line="58"/>
        <source>Do you want replay it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
